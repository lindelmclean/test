## Download software files from GitHub ##
$clnt = new-object System.Net.WebClient
$url = "https://github.com/lindelmclean/test/blob/main/CLOUD_Icons.zip?raw=true"
$url2 = "https://github.com/lindelmclean/test/blob/main/vpn-files.zip?raw=true"
$file = "C:\Temp\CLOUD_Icons.zip"
$file2 = "C:\Temp\vpn-files.zip"
$clnt.DownloadFile($url, $file)
$clnt.DownloadFile($url2, $file2)

## Unzip file ##
Expand-Archive -LiteralPath C:\Temp\CLOUD_Icons.zip -DestinationPath C:\users\public\Desktop
Expand-Archive -LiteralPath C:\Temp\vpn-files.zip -DestinationPath C:\Temp\vpn-files

## Set the source and destination ##
$source = 'https://cdn.watchguard.com/SoftwareCenter/Files/MUVPN_SSL/12_7/WG-MVPN-SSL_12_7.exe'
$destination = 'C:\temp\'
$fp = 'C:\temp\WG-MVPN-SSL_12_7.exe'

## Create the Download Request ##
Invoke-RestMethod -Uri $source -Outfile $fp

## Install WatchGuard VPN ##
$cmd = 'certutil.exe -addstore TrustedPublisher c:\temp\vpn-files\OpenVPN.cer'
$ret = Start-Process 'powershell.exe' -Verb RunAs -ArgumentList "-Command $cmd" -Wait -PassThru

Start-Process $fp -ArgumentList "/silent /verysilent /Components=main,tapdriver /tasks=desktopicon"

## Copy VPN script into StartUp folder ##
Copy-Item -Path "c:\temp\vpn-files\vpnserver.bat" -Destination "C:\programdata\microsoft\Windows\Start Menu\Programs\StartUp"

## Delete Temporary Folder ##
Remove-Item c:\temp\* -Recurse -Force

## End of File ##