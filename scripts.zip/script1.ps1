## Create passwords and computer name ##
$hostname = Read-Host 'Enter computer name'
$Password = Read-Host 'Local Admin Password' -AsSecureString
$Password2 = Read-Host 'Local User Password' -AsSecureString

## Change computer name ##
Rename-Computer $hostname
Write-Host "Computer name changed!"

## Create various accounts ##
Set-LocalUser -Name Administrator -Password $Password
Set-LocalUser -Name Administrator -PasswordNeverExpires 1
Set-LocalUser -Name Admin -Password $Password
Set-LocalUser -Name Admin -PasswordNeverExpires 1
New-LocalUser -Name Calligo -Password $Password 
Set-LocalUser -Name Calligo -PasswordNeverExpires 1
New-LocalUser -Name User -Password $Password2
Set-LocalUser -Name User -PasswordNeverExpires 1
Write-Host "Accounts created!"

## Users to groups ##
Add-LocalGroupMember -Group Administrators -Member Calligo
Add-LocalGroupMember -Group Users -Member User
Write-Host "Accounts added to groups!"

## Create new user directory without logon ##
$cred = New-Object System.Management.Automation.PSCredential -ArgumentList User,$Password2
Start-Process cmd /c -WindowStyle Hidden -Credential $cred -ErrorAction SilentlyContinue
Write-Host "User profile created!"

## Run another script ##
$command2 = "c:\temp\scripts\script2.ps1"
Invoke-Expression $command2